# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Get App Hanlders",
    "author" : "blanchsb", 
    "description" : "List all of the active app handlers in the current blender instance",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "VIEW3D",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "System" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
class SNA_OT_Copy_To_Clipboard_F18B4(bpy.types.Operator):
    bl_idname = "sna.copy_to_clipboard_f18b4"
    bl_label = "Copy to Clipboard"
    bl_description = "Copy the app handler function to the clipboard"
    bl_options = {"REGISTER", "UNDO"}
    sna_app_handler_function: bpy.props.StringProperty(name='app handler function', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.window_managers['WinMan'].clipboard = self.sna_app_handler_function
        bpy.ops.sn.copy_data_path(path=bpy.data.window_managers['WinMan'].clipboard, type='String', required='')
        self.report({'INFO'}, message='Copied hook: ' + bpy.data.window_managers['WinMan'].clipboard)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Get_App_Handlers_5C8Dc(bpy.types.Operator):
    bl_idname = "sna.get_app_handlers_5c8dc"
    bl_label = "Get App Handlers"
    bl_description = "Generate the full list of event handlers and modules where they are defined"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.preferences.addons['get_app_hanlders'].preferences.sna_app_handlers.clear()
        attr_name = None
        hand_list = None
        attr_name = []
        hand_list = []
        for attr in dir(bpy.app.handlers):
            hand = getattr(bpy.app.handlers, attr)
            if isinstance(hand, list) and hand:
                attr_name.append(attr)
                hand_list.append(hand)
                print(f'\nHandler:{attr}')
                print(f'hand: {list(hand)}')
                for hook in hand:
                    print(f"Hook {hook.__name__} in module {hook.__module__}")
        if attr_name:
            for i_588D6 in range(len(attr_name)):
                item_AF786 = bpy.context.preferences.addons['get_app_hanlders'].preferences.sna_app_handlers.add()
                item_AF786.handler_name = attr_name[i_588D6]
                for i_FC7F2 in range(len(hand_list[i_588D6])):
                    item_1C23C = item_AF786.handler_functions.add()
                    item_1C23C.function_hook = getattr(hand_list[i_588D6][i_FC7F2], '__name__', None)
                    item_1C23C.module = getattr(hand_list[i_588D6][i_FC7F2], '__module__', None)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Filter_Extension_Search_201Fc(bpy.types.Operator):
    bl_idname = "sna.filter_extension_search_201fc"
    bl_label = "Filter Extension Search"
    bl_description = "See if the module is an extension (add-on) in the Preferences"
    bl_options = {"REGISTER", "UNDO"}
    sna_possible_extension: bpy.props.StringProperty(name='possible_extension', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.window_managers['WinMan'].addon_search = self.sna_possible_extension
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
        self.report({'INFO'}, message='Possible Extension: ' + self.sna_possible_extension + ' filtered in Add-ons')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_uif_get_app_handlers_67FBD(layout_function, ):
    col_A9C88 = layout_function.column(heading='', align=True)
    col_A9C88.alert = False
    col_A9C88.enabled = True
    col_A9C88.active = True
    col_A9C88.use_property_split = True
    col_A9C88.use_property_decorate = False
    col_A9C88.scale_x = 1.0
    col_A9C88.scale_y = 1.0
    col_A9C88.alignment = 'Expand'.upper()
    col_A9C88.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = col_A9C88.operator('sna.get_app_handlers_5c8dc', text='Get App Handlers', icon_value=0, emboss=True, depress=False)
    for i_9AC78 in range(len(bpy.context.preferences.addons['get_app_hanlders'].preferences.sna_app_handlers)):
        col_A9C88.separator(factor=3.0)
        col_A9C88.label(text=bpy.context.preferences.addons['get_app_hanlders'].preferences.sna_app_handlers[i_9AC78].handler_name, icon_value=0)
        col_CE544 = col_A9C88.column(heading='', align=False)
        col_CE544.alert = False
        col_CE544.enabled = True
        col_CE544.active = True
        col_CE544.use_property_split = False
        col_CE544.use_property_decorate = False
        col_CE544.scale_x = 1.0
        col_CE544.scale_y = 1.0
        col_CE544.alignment = 'Expand'.upper()
        col_CE544.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_C3411 = col_CE544.row(heading='', align=False)
        row_C3411.alert = False
        row_C3411.enabled = True
        row_C3411.active = True
        row_C3411.use_property_split = False
        row_C3411.use_property_decorate = False
        row_C3411.scale_x = 1.0
        row_C3411.scale_y = 1.0
        row_C3411.alignment = 'Expand'.upper()
        row_C3411.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_C3411.label(text='Modules', icon_value=101)
        row_C3411.label(text='Functions', icon_value=101)
        box_08A01 = col_CE544.box()
        box_08A01.alert = False
        box_08A01.enabled = True
        box_08A01.active = True
        box_08A01.use_property_split = False
        box_08A01.use_property_decorate = False
        box_08A01.alignment = 'Expand'.upper()
        box_08A01.scale_x = 1.0
        box_08A01.scale_y = 1.0
        if not True: box_08A01.operator_context = "EXEC_DEFAULT"
        for i_C5095 in range(len(bpy.context.preferences.addons['get_app_hanlders'].preferences.sna_app_handlers[i_9AC78].handler_functions)):
            row_AAAEB = box_08A01.row(heading='', align=False)
            row_AAAEB.alert = False
            row_AAAEB.enabled = True
            row_AAAEB.active = True
            row_AAAEB.use_property_split = False
            row_AAAEB.use_property_decorate = False
            row_AAAEB.scale_x = 1.0
            row_AAAEB.scale_y = 1.0
            row_AAAEB.alignment = 'Expand'.upper()
            row_AAAEB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_AAAEB.label(text='', icon_value=101)
            op = row_AAAEB.operator('sna.filter_extension_search_201fc', text=bpy.context.preferences.addons['get_app_hanlders'].preferences.sna_app_handlers[i_9AC78].handler_functions[i_C5095].module, icon_value=30, emboss=False, depress=False)
            op.sna_possible_extension = bpy.context.preferences.addons['get_app_hanlders'].preferences.sna_app_handlers[i_9AC78].handler_functions[i_C5095].module.split('.')[0]
            op = row_AAAEB.operator('sna.copy_to_clipboard_f18b4', text=bpy.context.preferences.addons['get_app_hanlders'].preferences.sna_app_handlers[i_9AC78].handler_functions[i_C5095].function_hook, icon_value=598, emboss=False, depress=False)
            op.sna_app_handler_function = bpy.context.preferences.addons['get_app_hanlders'].preferences.sna_app_handlers[i_9AC78].handler_functions[i_C5095].function_hook


class SNA_PT_APP_HANDLERS_26D6B(bpy.types.Panel):
    bl_label = 'App Handlers'
    bl_idname = 'SNA_PT_APP_HANDLERS_26D6B'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Tool'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_uif_get_app_handlers_67FBD(layout_function, )


class SNA_GROUP_sna_handler_functions_group(bpy.types.PropertyGroup):
    function_hook: bpy.props.StringProperty(name='Function (Hook)', description='The function that makes use of the handler', default='', subtype='NONE', maxlen=0)
    module: bpy.props.StringProperty(name='Module', description='The module that the function is defined in', default='', subtype='NONE', maxlen=0)


class SNA_GROUP_sna_handlers_group(bpy.types.PropertyGroup):
    handler_name: bpy.props.StringProperty(name='Handler Name', description='App Hanlder Name', default='', subtype='NONE', maxlen=0)
    handler_functions: bpy.props.CollectionProperty(name='Handler Functions', description='', type=SNA_GROUP_sna_handler_functions_group)


class SNA_AddonPreferences_9A2AB(bpy.types.AddonPreferences):
    bl_idname = 'get_app_hanlders'
    sna_app_handlers: bpy.props.CollectionProperty(name='App Handlers', description='', type=SNA_GROUP_sna_handlers_group)
    sna_app_handler_index: bpy.props.IntProperty(name='App Handler Index', description='App Handler Item', default=0, subtype='NONE')
    sna_handlers_function_index: bpy.props.IntProperty(name='Handlers Function Index', description='', default=0, subtype='NONE')

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout_function = layout
            sna_uif_get_app_handlers_67FBD(layout_function, )


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_handler_functions_group)
    bpy.utils.register_class(SNA_GROUP_sna_handlers_group)
    bpy.utils.register_class(SNA_OT_Copy_To_Clipboard_F18B4)
    bpy.utils.register_class(SNA_OT_Get_App_Handlers_5C8Dc)
    bpy.utils.register_class(SNA_OT_Filter_Extension_Search_201Fc)
    bpy.utils.register_class(SNA_AddonPreferences_9A2AB)
    bpy.utils.register_class(SNA_PT_APP_HANDLERS_26D6B)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_GROUP_sna_handlers_group)
    bpy.utils.unregister_class(SNA_GROUP_sna_handler_functions_group)
    bpy.utils.unregister_class(SNA_OT_Copy_To_Clipboard_F18B4)
    bpy.utils.unregister_class(SNA_OT_Get_App_Handlers_5C8Dc)
    bpy.utils.unregister_class(SNA_OT_Filter_Extension_Search_201Fc)
    bpy.utils.unregister_class(SNA_AddonPreferences_9A2AB)
    bpy.utils.unregister_class(SNA_PT_APP_HANDLERS_26D6B)
